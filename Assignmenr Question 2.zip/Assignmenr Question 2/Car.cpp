#include "Car.h"

Car::Car(string b, string m, int y, string f, int d)
: Vehicle(b, m, y)  
{
    fuelType = f;
    doors = d;
    cout << "Car Constructor Called\n";
}

void Car::displayCarDetails() {
    showVehicleInfo();
    cout << "Fuel Type: " << fuelType << endl;
    cout << "Doors: " << doors << endl;
}