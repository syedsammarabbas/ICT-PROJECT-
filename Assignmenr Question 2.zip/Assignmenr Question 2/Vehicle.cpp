#include "Vehicle.h"

Vehicle::Vehicle() {
    cout << "Vehicle Default Constructor Called\n";
}

Vehicle::Vehicle(string b, string m, int y) {
    brand = b;
    model = m;
    year = y;
    cout << "Vehicle Parameterized Constructor Called " <<endl;
}

void Vehicle::showVehicleInfo() {
    cout << "Brand: " << brand << endl;
    cout << "Model: " << model << endl;
    cout << "Year: " << year << endl;
}