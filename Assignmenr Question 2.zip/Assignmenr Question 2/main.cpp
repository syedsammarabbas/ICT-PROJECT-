#include "Car.h"
#include "Bike.h"

int main() {

    cout << "\n ****Creating Car***  "<<endl;;
    Car c("Toyota", "Corolla", 2020, "Petrol", 4);

    cout << "\nCar Details: "<<endl;;
    c.displayCarDetails();

    cout << "\n*** Creating Bike *** " <<endl;;
    Bike b("Honda", "CBR", 2022, 150, "Sports");

    cout << "\nBike Details:\n";
    b.showBikeProfile();

    return 0;
}