#include "Person.h"

Person::Person() {
    name = "Unknown";
    age = 0;
}

Person::Person(string na, int ag, string ge, string con, string ad) {
    name = na;
    age = ag;
    gender = ge;
    contact = con;
    address = ad;
}

void Person::initializePersonData() {
    cout << "Name: "; 
    cin >> name;
    cout << "Age: "; 
    cin >> age;
    cout << "Gender: "; 
    cin >> gender;
    cout << "Contact: "; 
    cin >> contact;
    cout << "Address: "; 
    cin >> address;
}

void Person::showPersonProfile() {
    cout << name << " " << age << " " << gender << endl;
}