#include "Student.h"

Student::Student() : Person() {}

void Student::assignStudentDetails() {
    initializePersonData();
    cout << "Student ID: ";
     cin >> studentID;
    cout << "CGPA: ";
     cin >> cgpa;
    cout << "Year: "; 
    cin >> year;
}

void Student::printStudentRecord() {
    showPersonProfile();
    cout << studentID << " " << cgpa << " " << year << endl;
}