#include "Student.h"
#include "GraduateStudent.h"

int main() {
    Student students[5];
    GraduateStudent grads[5];

    int sCount = 0;
    int gCount = 0;

    int choice;

    do {
        cout << "\n**************** MENU **************\n";
        cout << "1. Add Student\n";
        cout << "2. Add Graduate Student\n";
        cout << "3. Show All Students\n";
        cout << "4. Show Graduate Students\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if(choice == 1) {
            if(sCount < 5) {
                cout << "\nEnter Student Data:\n";
                students[sCount].assignStudentDetails();
                sCount++;
            } else {
                cout << "Student list full!\n";
            }
        }

        else if(choice == 2) {
            if(gCount < 5) {
                cout << "\nEnter Graduate Data: "<<endl;;
                grads[gCount].updateResearchInfo();
                gCount++;
            } else {
                cout << "Graduate list full!" <<endl;
            }
        }

        else if(choice == 3) {
            cout << "\n***** Students ******" <<endl;;
            for(int i = 0; i < sCount; i++) {
                students[i].printStudentRecord();
            }
        }

        else if(choice == 4) {
            cout << "\n***** Graduate Students *****"<<endl;;
            for(int i = 0; i < gCount; i++) {
                grads[i].displayGraduateProfile();
            }
        }

    } while(choice != 0);

    return 0;
}