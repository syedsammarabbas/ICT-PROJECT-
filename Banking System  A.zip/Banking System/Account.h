#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <iostream>
#include <string>

using namespace std;

class Account {
protected:
    string accNumber;
    double balance;

public:
    Account(string num, double bal) {
        accNumber = num;
        balance = bal;
    }

    virtual void deposit(double amount) {
        if (amount <= 0) {
            cout << "Error: Deposit amount must be greater than zero." << endl;
            return;
        }
        balance += amount;
    }

    virtual void withdraw(double amount) {
        if (amount <= 0) {
            cout << "Error: Enter a valid withdrawal amount." << endl;
            return;
        }
        if (amount > balance) {
            cout << "Error: Not enough balance in account " << accNumber << endl;
            return;
        }
        balance -= amount;
    }

    virtual void showInfo() {
        cout << "Account No: " << accNumber << endl;
        cout << "Balance:    " << balance << endl;
    }

    double getBalance() { return balance; }
    string getAccNumber() { return accNumber; }

    virtual ~Account() {}
};

#endif
