#ifndef CLIENT_H
#define CLIENT_H

#include "Account.h"

const int MAX_ACCOUNTS = 10;

class Client {
private:
    string fullName;
    string cID;
    Account* accounts[MAX_ACCOUNTS];
    int totalAccounts;

public:
    Client(string name, string id) {
        fullName = name;
        cID = id;
        totalAccounts = 0;
    }

    void addAccount(Account* acc) {
        if (totalAccounts < MAX_ACCOUNTS) {
            accounts[totalAccounts] = acc;
            totalAccounts++;
        } else {
            cout << "Cannot add more accounts." << endl;
        }
    }

    void showAllAccounts() {
        cout << "\nClient Name: " << fullName << "  |  ID: " << cID << endl;
        for (int i = 0; i < totalAccounts; i++) {
            accounts[i]->showInfo();
            cout << endl;
        }
    }

    Account* getAccount(int index) {
        if (index < 0 || index >= totalAccounts) {
            cout << "Invalid account index." << endl;
            return nullptr;
        }
        return accounts[index];
    }

    string getName() { return fullName; }

    ~Client() {
        for (int i = 0; i < totalAccounts; i++) {
            delete accounts[i];
        }
    }
};

#endif
