#ifndef CURRENTACCOUNT_H
#define CURRENTACCOUNT_H

#include "Account.h"

class CurrentAccount : public Account {
private:
    double overdraft;

public:
    CurrentAccount(string num, double bal, double overdraftLimit)
        : Account(num, bal) {
        overdraft = overdraftLimit;
    }

    void withdraw(double amount) override {
        if (amount <= 0) {
            cout << "Error: Amount should be positive." << endl;
            return;
        }
        if (amount > balance + overdraft) {
            cout << "Error: Amount exceeds overdraft limit for account " << accNumber << endl;
            return;
        }
        balance -= amount;
    }

    void showInfo() override {
        cout << "-- Current Account --" << endl;
        cout << "Account No:     " << accNumber << endl;
        cout << "Balance:        " << balance << endl;
        cout << "Overdraft Limit:" << overdraft << endl;
    }
};

#endif
