#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H

#include "Account.h"

class SavingsAccount : public Account {
private:
    double rate;

public:
    SavingsAccount(string num, double bal, double interestRate)
        : Account(num, bal) {
        rate = interestRate;
    }

    void withdraw(double amount) override {
        if (amount <= 0) {
            cout << "Error: Amount should be positive." << endl;
            return;
        }
        if (amount > balance) {
            cout << "Error: Savings account does not allow overdraft." << endl;
            return;
        }
        balance -= amount;
    }

    void addInterest() {
        double interest = balance * (rate / 100);
        balance += interest;
        cout << "Interest of " << interest << " added. Balance is now: " << balance << endl;
    }

    void showInfo() override {
        cout << " Savings Account " << endl;
        cout << "Account No:    " << accNumber << endl;
        cout << "Balance:       " << balance << endl;
        cout << "Interest Rate: " << rate << "%" << endl;
    }
};

#endif
