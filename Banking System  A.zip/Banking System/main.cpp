#include <iostream>
#include "Account.h"
#include "SavingsAccount.h"
#include "CurrentAccount.h"
#include "Client.h"

using namespace std;

template <typename From, typename To>
void transfer(From* sender, To* receiver, double amount) {
    if (sender->getBalance() < amount) {
        cout << "Transfer failed: Insufficient funds." << endl;
        return;
    }
    sender->withdraw(amount);
    receiver->deposit(amount);
    cout << "Transfer of " << amount << " completed successfully." << endl;
}

int main() {

    SavingsAccount* sa1 = new SavingsAccount("121", 9000, 4.5);
    CurrentAccount* ca1 = new CurrentAccount("111", 4500, 1500);

    Client c1("Abeeka", "111");
    c1.addAccount(sa1);
    c1.addAccount(ca1);

    cout << " Account Details: " << endl;
    c1.showAllAccounts();

    cout << "Deposit Test:: " << endl;
    sa1->deposit(3000);
    cout << "Deposited 3000 into savings." << endl;

    cout << "\nWithdrawal Test" << endl;
    ca1->withdraw(4500);
    cout << "Withdrew 5500 from current account." << endl;

    cout << "\n Overdraft Limit Test" << endl;
    ca1->withdraw(9000);

    cout << "\nSavings Overdraft Test" << endl;
    sa1->withdraw(40000);

    cout << "\nInterest Test" << endl;
    sa1->addInterest();

    SavingsAccount* sa2 = new SavingsAccount("122", 2000, 3.0);
    Client c2("Farooq", "122");
    c2.addAccount(sa2);

    cout << "\nFund Transfer" << endl;
    transfer(sa1, sa2, 1500);

    cout << "\nUpdated Details " << endl;
    c1.showAllAccounts();
    c2.showAllAccounts();

    return 0;
}
