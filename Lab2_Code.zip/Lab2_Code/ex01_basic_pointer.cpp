#include <iostream>
using namespace std;

int main() {
    int number = 25;
    int *ptr = &number;

    cout << "Value of variable   : " << number << endl;
    cout << "Address of variable : " << &number << endl;
    cout << "Value of pointer    : " << ptr << endl;      
    cout << "Dereferenced value  : " << *ptr << endl;
    return 0;
}
