#include <iostream>
using namespace std;

int main() {
    int arr[10];
    int *ptr = arr;

    cout << "Enter 10 integers: ";
    for (int i = 0; i < 10; i++) {
        cin >> *(ptr + i); 
    }

    cout << "Array elements: ";
    for (int i = 0; i < 10; i++) {
        cout << *(ptr + i) << " "; 
    }

    cout << endl;
    return 0;
}