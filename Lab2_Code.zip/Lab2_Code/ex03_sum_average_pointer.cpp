#include <iostream>
using namespace std;

int main() {
    int data[] = {10, 20, 30, 40, 50, 60};
    int SIZE = 6;
    
    int *p = data;
    int sum = 0;


    for (int i = 0; i < SIZE; i++) {
        sum += *p; 
        p++;     
    }

    double average = (double)sum / SIZE;

    cout << "Sum     = " << sum << endl;
    cout << "Average = " << average << endl;

    return 0;
}