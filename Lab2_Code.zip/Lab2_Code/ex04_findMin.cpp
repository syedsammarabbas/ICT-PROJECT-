#include <iostream>
using namespace std;
int findMin(int arr[], int size) {
    int minimum = arr[0];

    for (int i = 1; i < size; i++) {
        if (arr[i] < minimum) {
            minimum = arr[i]; 
        }
    }
    
    return minimum;
}

int main() {
    int values[] = {42, 17, 93, 8, 56, 21};
    int size = 6; 

    cout << "Minimum = " << findMin(values, size) << endl;

    return 0;
}