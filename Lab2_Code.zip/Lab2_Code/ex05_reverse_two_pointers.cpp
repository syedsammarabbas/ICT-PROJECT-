#include <iostream>
using namespace std;

int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    int size = 7;

    cout << "Original Array: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    int* left = arr;             
    int* right = arr + size - 1;  

    while (left < right) {
   
        int temp = *left;
        *left = *right;
        *right = temp;

   
        left++; 
        right--;  
    }
    cout << "Reversed Array: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}