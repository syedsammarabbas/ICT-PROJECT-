#include <iostream>
using namespace std;

void doubleValue(int *x) {
    *x = *x * 2;
}

int main() {
    int n = 15;
    cout << "Before: " << n << endl;
    doubleValue(&n);
    cout << "After : " << n << endl;
    return 0;
}
