#include <iostream>
using namespace std;
int add(int a, int b) { 
    return a + b; 
}

int subtract(int a, int b) { 
    return a - b; 
}

int multiply(int a, int b) { 
    return a * b; 
}

int main() {
    int a, b, choice;
    int (*funcPtr)(int, int);

    cout << "Enter two numbers: ";
    cin >> a >> b;

    cout << "1. Add\n2. Subtract\n3. Multiply\nEnter choice: ";
    cin >> choice;
    if (choice == 1) {
        funcPtr = add;
    } 
    else if (choice == 2) {
        funcPtr = subtract;
    } 
    else if (choice == 3) {
        funcPtr = multiply;
    } 
    else {
        cout << "Invalid Choice!";
        return 0;
    }
    cout << "Result = " << funcPtr(a, b) << endl;

    return 0;
}