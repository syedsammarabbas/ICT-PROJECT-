#include <iostream>
using namespace std;

void displayArray(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        cout << *(arr + i) << " ";
    }
    cout << endl;
}

int main() {
    int nums[] = {5, 10, 15, 20, 25};
    displayArray(nums, 5);
    return 0;
}
