#include <iostream>
using namespace std;

class Rectangle {
private:
    double length;
    double width;

public:
    void setLength(double l) { 
        length = l;
     }
    void setWidth(double w)  { 
        width = w;
     }
    double area() { 
        return length * width;
     }
};

int main() {
    Rectangle r;
    r.setLength(5);
    r.setWidth(4);
    cout << "Area = " << r.area() << endl;
    return 0;
}
