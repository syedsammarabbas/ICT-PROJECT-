#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    double salary;

public:
    void input() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter salary: ";
        cin >> salary;
    }
    void display() {
        cout << "Name: " << name << endl;
        cout << "Salary: " << salary << endl;
    }
};

class Programmer : public Employee {
private:
    string programmingLanguage;

public:
    void input() {
        Employee::input();
        cout << "Enter programming language: ";
        cin >> programmingLanguage;
    }
    void display() {
        Employee::display();
        cout << "Language: " << programmingLanguage << endl;
    }
};

int main() {
    Programmer p;
    p.input();
    p.display();
    return 0;
}
