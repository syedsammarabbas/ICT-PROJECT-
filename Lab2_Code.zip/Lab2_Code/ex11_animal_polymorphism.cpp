#include <iostream>
using namespace std;

class Animal {
public:
    virtual void sound() { 
        cout << "Some generic animal sound" << endl; 
    }
    virtual ~Animal() {}
};

class Cat : public Animal {
public:
    void sound() override { 
        cout << "Meow" << endl;
     }
};

class Dog : public Animal {
public:
    void sound() override { 
        cout << "Woof" << endl;
     }
};

int main() {
    Animal *ptr;
    Cat c;
    Dog d;

    ptr = &c;
    ptr->sound();  
    ptr = &d;
    ptr->sound();  
    return 0;
}
