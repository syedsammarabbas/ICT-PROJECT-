#include <iostream>
using namespace std;

class Student {
private:
    int rollNo;
    int marks[5];

public:
    void input() {
        cout << "Enter roll number: ";
        cin >> rollNo;
        cout << "Enter 5 marks: ";
        for (int i = 0; i < 5; i++) {
            cin >> marks[i];
        }
    }

    double averageUsingArray() {
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum = sum + marks[i];
        }
        return sum / 5.0;
    }

    double averageUsingPointer() {
        int sum = 0;
        int *p = marks;
        for (int i = 0; i < 5; i++) {
            sum = sum + *(p + i);
        }
        return sum / 5.0;
    }

    void display() {
        cout << "Roll No: " << rollNo << endl;
        cout << "Average (array): " << averageUsingArray() << endl;
        cout << "Average (pointer): " << averageUsingPointer() << endl;
    }
};

int main() {
    Student s;
    s.input();
    s.display();
    return 0;
}
