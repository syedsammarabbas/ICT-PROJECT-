#include <iostream>
using namespace std;

int sumTo(int n) {
    if (n == 0)
        return 0;
    return n + sumTo(n - 1);
}

int main() {
    int n;
    cout << "Enter n: ";
    cin >> n;
    cout << "Sum = " << sumTo(n) << endl;
    return 0;
}
