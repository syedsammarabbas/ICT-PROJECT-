#include <iostream>
using namespace std;

void printArray(int arr[], int index, int size) {
    if (index == size)
        return;
    cout << arr[index] << " ";
    printArray(arr, index + 1, size);
}

int main() {
    int arr[5] = {3, 6, 9, 12, 15};
    printArray(arr, 0, 5);
    cout << endl;
    return 0;
}
