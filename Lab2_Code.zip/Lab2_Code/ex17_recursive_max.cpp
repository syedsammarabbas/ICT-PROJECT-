#include <iostream>
using namespace std;

int findMax(int arr[], int n) {
    if (n == 1)
        return arr[0];
    int max = findMax(arr, n - 1);
    if (arr[n - 1] > max)
        return arr[n - 1];
    return max;
}

int main() {
    int arr[5] = {14, 82, 5, 67, 39};
    cout<<"*************************\n";
    cout << "Maximum = " << findMax(arr, 5) << endl;
    return 0;
}
