#include <iostream>
using namespace std;

int calls = 0;

int fib(int n) {
    calls++;
    if (n <= 1)
        return n;
    return fib(n - 1) + fib(n - 2);
}

int main() {
    for (int n = 0; n <= 10; n++) {
        calls = 0;
        int result = fib(n);
        cout << "fib(" << n << ") = " << result << "   calls = " << calls << endl;
    }
    return 0;
}
