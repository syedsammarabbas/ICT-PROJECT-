#include <iostream>
using namespace std;

int main() {
    int arr[10];
    int *p = arr;

    cout << "Enter 10 numbers: ";
    for (p = arr; p < arr + 10; p++) {
        cin >> *p;
    }

    int sum = 0;
    int min = *arr;
    int max = *arr;

    for (p = arr; p < arr + 10; p++) {
        sum = sum + *p;
        if (*p < min) min = *p;
        if (*p > max) max = *p;
    }

    cout << "Sum = " << sum << endl;
    cout << "Average = " << sum / 10.0 << endl;
    cout << "Minimum = " << min << endl;
    cout << "Maximum = " << max << endl;
    return 0;
}
