#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int rollNo;
    int marks[5];

public:
    void input() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter roll number: ";
        cin >> rollNo;
        cout << "Enter 5 marks: ";
        for (int i = 0; i < 5; i++) {
            cin >> marks[i];
        }
    }

    double average() {
        int sum = 0;
        int *p = marks;
        for (int i = 0; i < 5; i++) {
            sum = sum + *(p + i);
        }
        return sum / 5.0;
    }

    void display() {
        cout << "Name: " << name << endl;
        cout << "Roll No: " << rollNo << endl;
        cout << "Average: " << average() << endl;
    }
};

int main() {
    Student s;
    s.input();
    s.display();
    return 0;
}
