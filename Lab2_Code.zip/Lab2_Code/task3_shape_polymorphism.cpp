#include <iostream>
using namespace std;

class Shape {
public:
    virtual double area() {
        return 0;
    }
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) { 
        radius = r;
     }
    double area() { 
        return 3.14 * radius * radius; }
};

class Rectangle : public Shape {
private:
    double length, width;
public:
    Rectangle(double l, double w) { 
        length = l; 
        
        width = w;
     }
    double area() { 
        return length * width; 
    }
};

int main() {
    double r, l, w;
    cout << "Enter radius: ";
    cin >> r;
    cout << "Enter length and width: ";
    cin >> l >> w;

    Circle c(r);
    Rectangle rect(l, w);
    Shape *ptr;

    ptr = &c;
    cout << "Circle area = " << ptr->area() << endl;
    ptr = &rect;
    cout << "Rectangle area = " << ptr->area() << endl;
    return 0;
}
