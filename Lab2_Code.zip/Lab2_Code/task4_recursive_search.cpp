#include <iostream>
using namespace std;

bool search(int arr[], int size, int target) {
    if (size == 0)
        return false;
    if (arr[size - 1] == target)
        return true;
    return search(arr, size - 1, target);
}

int main() {
    int arr[100];
    int n, target;

    cout << "Enter size: ";
    cin >> n;
    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    cout << "Enter target: ";
    cin >> target;

    if (search(arr, n, target))
        cout << "true" << endl;
    else
        cout << "false" << endl;
    return 0;
}
