#include <iostream>
using namespace std;

int main() {
    int arr[6] = {12, 45, 3, 67, 23, 9};
    int n = 6;
    int maxVal = arr[0];
    int comparisons = 0;

    for (int i = 1; i < n; i++) {
        comparisons++;
        if (arr[i] > maxVal)
            maxVal = arr[i];
    }

    cout << "Maximum = " << maxVal << endl;
    cout << "Comparisons = " << comparisons << endl;
    return 0;
}
