#include <iostream>
#include <string>
using namespace std;

int main() {
    string s = "ALGORITHM";
    int n = s.length();
    int operations = 0;

    for (int i = 0; i < n; i++) {
        cout << s[i];
        operations++;
    }
    cout << endl;
    cout << "Operations = " << operations << endl;
    return 0;
}
