#include <iostream>
using namespace std;

int main() {
    int n = 4;
    int M[4][4];
    int assignments = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            M[i][j] = 0;
            assignments++;
        }
    }

    cout << "Assignments = " << assignments << endl;
    cout << "M[3][3] = " << M[3][3] << endl;
    return 0;
}
