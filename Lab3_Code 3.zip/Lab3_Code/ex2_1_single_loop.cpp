#include <iostream>
using namespace std;

int main() {
    int n = 10;
    int operations = 0;

    for (int i = 0; i < n; i++) {
        cout << i;
        operations++;
    }
    cout << endl;
    cout << "Operations = " << operations << endl;
    return 0;
}
