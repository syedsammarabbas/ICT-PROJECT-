#include <iostream>
using namespace std;

int main() {
    int n = 1000;
    int i = n;
    int operations = 0;

    while (i > 1) {
        i = i / 2;
        operations++;
    }

    cout << "**************** "  << endl;
    cout << "Operations = " << operations << endl;
    cout << "**************** "  << endl;
    return 0;
}
