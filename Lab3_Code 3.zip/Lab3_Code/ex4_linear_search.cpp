#include <iostream>
using namespace std;

int linearSearch(int arr[], int n, int key, int &comparisons) {
    for (int i = 0; i < n; i++) {
        comparisons++;
        if (arr[i] == key)
            return i;
    }
    return -1;
}

int main() {
    int arr[5] = {10, 20, 30, 40, 50};
    int comparisons = 0;
    int index;

    comparisons = 0;
    index = linearSearch(arr, 5, 10, comparisons);
    cout << "Search 10: index = " << index << ", comparisons = " << comparisons << endl;

    comparisons = 0;
    index = linearSearch(arr, 5, 50, comparisons);
    cout << "Search 50: index = " << index << ", comparisons = " << comparisons << endl;

    comparisons = 0;
    index = linearSearch(arr, 5, 99, comparisons);
    cout << "Search 99: index = " << index << ", comparisons = " << comparisons << endl;

    return 0;
}
