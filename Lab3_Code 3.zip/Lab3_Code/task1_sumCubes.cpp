#include <iostream>
using namespace std;

int sumCubes(int n, int &operations) {
    int partialSum = 0;
    operations++;
    for (int i = 1; i <= n; i++) {
        partialSum += i * i * i;
        operations++;
    }
    return partialSum;
}

int main() {
    int n = 10;
    int operations = 0;

    int result = sumCubes(n, operations);
    cout << "Sum of cubes = " << result << endl;
    cout << "Operations = " << operations << endl;
    return 0;
}
