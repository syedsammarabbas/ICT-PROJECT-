#include <iostream>
using namespace std;

int linearSearch(int arr[], int n, int key, int &comparisons) {
    for (int i = 0; i < n; i++) {
        comparisons++;
        if (arr[i] == key)
            return i;
    }
    return -1;
}

int main() {
    int arr[10] = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50};
    int comparisons;

    comparisons = 0;
    linearSearch(arr, 10, 5, comparisons);
    cout << "Key at first position: comparisons = " << comparisons << endl;

    comparisons = 0;
    linearSearch(arr, 10, 50, comparisons);
    cout << "Key at last position: comparisons = " << comparisons << endl;

    comparisons = 0;
    linearSearch(arr, 10, 100, comparisons);
    cout << "Missing key: comparisons = " << comparisons << endl;

    return 0;
}
