#include <iostream>
using namespace std;

int countAssignments(int n) {
    int assignments = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            assignments++; 
        }
    }
    return assignments;
}

int main() {

    for (int n = 2; n <= 4; n++) {
        cout << "n = " << n << " -> Assignments = " << countAssignments(n) << endl;
    }

    return 0;
}
