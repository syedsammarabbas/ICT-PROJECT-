#include <iostream>
using namespace std;

void process(int &counter) {
    counter++;
}

int main() {
    int sizes[3] = {10, 100, 1000};

    for (int s = 0; s < 3; s++) {
        int n = sizes[s];
        int countA = 0;
        int countB = 0;

        for (int i = 0; i < n; i++) {
            process(countA);
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                process(countB);
            }
        }

        cout << "n = " << n << " -> Algorithm A calls = " << countA
             << ", Algorithm B calls = " << countB << endl;
    }
    return 0;
}
