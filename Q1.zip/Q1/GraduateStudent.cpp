#include "GraduateStudent.h"

void GraduateStudent::updateResearchInfo() {
    assignStudentDetails();
    cout << "Research Topic: "; 
    cin >> topic;
    cout << "Supervisor: "; 
    cin >> supervisor;
    cout << "Thesis Status: ";
    cin >> thesis;
}

void GraduateStudent::displayGraduateProfile() {
    printStudentRecord();
    cout << topic << " " << supervisor << " " << thesis << endl;
}