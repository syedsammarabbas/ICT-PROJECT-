#ifndef GRAD_H
#define GRAD_H

#include "Student.h"

class GraduateStudent : public Student {
private:
    string topic, supervisor, thesis;

public:
    void updateResearchInfo();
    void displayGraduateProfile();
};

#endif