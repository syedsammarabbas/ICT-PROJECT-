#include "Person.h"

Person::Person() {
    name = "Unknown";
    age = 0;
}

Person::Person(string n, int a, string g, string co, string ad) {
    name = n;
    age = a;
    gender = g;
    contact = co;
    address = ad;
}

void Person::initializePersonData() {
    cout << "Name: "; 
    cin >> name;
    cout << "Age: "; 
    cin >> age;
    cout << "Gender: "; 
    cin >> gender;
    cout << "Contact: "; 
    cin >> contact;
    cout << "Address: "; 
    cin >> address;
}

void Person::showPersonProfile() {
    cout << name << " " << age << " " << gender << endl;
}