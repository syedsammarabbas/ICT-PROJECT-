#ifndef PERSON_H
#define PERSON_H

#include <iostream>
using namespace std;

class Person {
protected:
    string name, gender, contact, address;
    int age;

public:
    Person();
    Person(string, int, string, string, string);

    void initializePersonData();
    void showPersonProfile();
};

#endif