#include "Student.h"
#include <iostream>

using namespace std;

Student::Student() : Person() {
    studentID = 0;
    cgpa = 0.0;
    year = 0;
}

void Student::assignStudentDetails() {
    initializePersonData();
    
    cout << "Enter Student ID: ";
    cin >> studentID;
    
    cout << "Enter CGPA: ";
    cin >> cgpa;
    
    cout << "Enter Year: "; 
    cin >> year;

    cin.ignore(); 
}

void Student::printStudentRecord() {
    showPersonProfile();

    cout << "ID: " << studentID << " | CGPA: " << cgpa << " | Year: " << year << endl;
}