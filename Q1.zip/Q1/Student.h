#ifndef STUDENT_H
#define STUDENT_H

#include "Person.h"

class Student : public Person {
protected:
    int studentID, year;
    float cgpa;

public:
    Student();
    void assignStudentDetails();
    void printStudentRecord();
};

#endif