#include "Student.h"
#include "GraduateStudent.h"

int main() {
    Student students[5];
    GraduateStudent grads[5];

    int sCount = 0;
    int gCount = 0;

    int choice;

    do {
        cout << "\n MENU \n";
        cout << "1. Add Student\n";
        cout << "2. Add Graduate Student\n";
        cout << "3. Show All Students\n";
        cout << "4. Show Graduate Students\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch(choice) {
        case 1:
            if(sCount < 5) {
                cout << "\nEnter Student Data:\n";
                students[sCount].assignStudentDetails();
                sCount++;
            } else {
                cout << "Student list full!\n";
            }
            break;

        case 2:
            if(gCount < 5) {
                cout << "\nEnter Graduate Data: " << endl;
                grads[gCount].updateResearchInfo();
                gCount++;
            } else {
                cout << "Graduate list full!" << endl;
            }
            break;

        case 3:
            cout << "\nStudents: " << endl;
            for(int i = 0; i < sCount; i++) {
                students[i].printStudentRecord();
            }
            break;

        case 4:
            cout << "\nGraduate Student:" << endl;
            for(int i = 0; i < gCount; i++) {
                grads[i].displayGraduateProfile();
            }
            break;

        case 0:
            cout << "Exiting" << endl;
            break;

        default:
            cout << "Invalid choice! Dubara try karein." << endl;
            break;
    }
} while(choice != 0);
    return 0;
}