#include "Bike.h"

Bike::Bike(string b, string m, int y, int e, string t)
: Vehicle(b, m, y) 
{
    engineCapacity = e;
    type = t;
    cout << "Bike Constructor Called\n";
}

void Bike::showBikeProfile() {
    showVehicleInfo();
    cout << "Engine: " << engineCapacity << "cc\n";
    cout << "Type: " << type << endl;
}