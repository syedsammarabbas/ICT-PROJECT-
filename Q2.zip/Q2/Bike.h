#ifndef BIKE_H
#define BIKE_H

#include "Vehicle.h"

class Bike : public Vehicle {
private:
    int engineCapacity;
    string type;

public:
    Bike(string, string, int, int, string);

    void showBikeProfile();
};

#endif