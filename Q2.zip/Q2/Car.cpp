#include "Car.h"
#include <iostream>

using namespace std;


Car::Car(string b, string m, int y, string f, int d)
: Vehicle(b, m, y), fuelType(f), doors(d)  
{
    cout << "Car Constructor Called for: " << fuelType << " car" << endl;
}

void Car::displayCarDetails() {
    cout << "----- Car Specifications -----" << endl;
    showVehicleInfo();
    cout << "Fuel System: " << fuelType << endl;
    cout << "Number of Doors: " << doors << endl;
}