#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"

class Car : public Vehicle {
private:
    string fuelType;
    int doors;

public:
    Car(string, string, int, string, int);

    void setCarSpecs();
    void displayCarDetails();
};

#endif