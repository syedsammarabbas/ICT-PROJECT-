#include "Vehicle.h"
#include <iostream>

using namespace std;

Vehicle::Vehicle() : brand("Unknown"), model("Unknown"), year(0) {
    cout << "Vehicle Default Constructor Called" << endl;
}

Vehicle::Vehicle(string b, string m, int y) : brand(b), model(m), year(y) {
    cout << "Vehicle Parameterized Constructor Called for " << brand << endl;
}

void Vehicle::showVehicleInfo() {
    cout << "--- Vehicle Information ---" << endl;
    cout << "Brand: " << brand << " | Model: " << model << " | Year: " << year << endl;
}