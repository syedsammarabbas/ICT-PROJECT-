#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
using namespace std;

class Vehicle {
private:
    string brand, model;
    int year;

public:
    Vehicle();
    Vehicle(string, string, int);

    void showVehicleInfo();
};

#endif