#include "Car.h"
#include "Bike.h"

int main() {

    cout << "\nCreating Car \n";
    Car c("Honda", "Civic", 2023, "Hybrid", 4);

    cout << "\nCar Details: "<<endl;;
    c.displayCarDetails();

    cout << "\n Creating Bike \n";
    Bike b("Suzuki", "GS150", 2024, 150, "Touring");

    cout << "\nBike Details:\n";
    b.showBikeProfile();

    return 0;
}