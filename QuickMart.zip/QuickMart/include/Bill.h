#ifndef BILL_H
#define BILL_H

#include <iostream>
#include <string>
#include <string>
#include <fstream>
using namespace std;

struct BillItem
{
    int productId;
    string productName;
    string productType;
    int qty;
    double unitPrice;
    double lineTotal;
};

class Bill
{
private:
    int billId;
    int cashierId;
    string cashierName;
    string customerName;
    string paymentMethod;

    BillItem items[30];
    int itemCount;

    double subtotal;
    double tax;
    double grandTotal;

public:
    Bill();
    Bill(int billId, int cashierId, string cashierName, string customerName);

    void addItem(int productId, string name, string type,
                 int qty, double unitPrice);

    void setPaymentMethod(string method);
    void calculateTotals();

    int getBillId();
    int getCashierId();
    double getGrandTotal();
    int getItemCount();

    void printReceipt(string storeName);

    void saveToFile(ofstream &file);
    void loadFromFile(ifstream &file);
};

#endif
