#ifndef BUNDLE_PRODUCT_H
#define BUNDLE_PRODUCT_H

#include "DiscountedProduct.h"
using namespace std;

class BundleProduct : public DiscountedProduct
{
private:
    int itemsInBundle;

public:
    BundleProduct();
    BundleProduct(int id, string name, double price,
                  int stock, double discount, int items);

    int getItemsInBundle();
    void setItemsInBundle(int n);

    double getFinalPrice();
    string getType();
    void display();

    void saveToFile(ofstream &file);
    void loadFromFile(ifstream &file);
};

#endif
