#ifndef CASHIER_H
#define CASHIER_H

#include "Employee.h"
using namespace std;
class Cashier : public Employee
{
private:
    int totalBills;
    double totalAmount;

public:
    Cashier();
    Cashier(int id, string name, string phone,
            string username, string password);

    void addSale(double amount);
    int getTotalBills();
    double getTotalAmount();

    void display();
    std::string getRole();

    void saveToFile(ofstream &file);
    void loadFromFile(ifstream &file);
};

#endif
