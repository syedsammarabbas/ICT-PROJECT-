#ifndef DISCOUNTED_PRODUCT_H
#define DISCOUNTED_PRODUCT_H

#include "Product.h"
using namespace std;
class DiscountedProduct : public Product
{
protected:
    double discount;

public:
    DiscountedProduct();
    DiscountedProduct(int id, string name, double price,
                      int stock, double discount);

    double getDiscount();
    void setDiscount(double d);

    double getFinalPrice();
    std::string getType();
    void display();

    void saveToFile(ofstream &file);
    void loadFromFile(ifstream &file);
};

#endif
