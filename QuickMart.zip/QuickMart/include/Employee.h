#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "Person.h"
#include <fstream>
using namespace std;
class Employee : public Person
{
protected:
    int id;
    string username;
    string password;

public:
    Employee();
    Employee(int id, string name, string phone,
             string username, string password);

    int getId();
    string getUsername();

    bool checkLogin(string user, string pass);

    virtual void display();
    virtual string getRole();

    virtual void saveToFile(ofstream &file);
    virtual void loadFromFile(ifstream &file);
};

#endif
