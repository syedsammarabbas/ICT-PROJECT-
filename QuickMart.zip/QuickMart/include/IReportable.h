#ifndef IREPORTABLE_H
#define IREPORTABLE_H

// Interface for multiple inheritance
class IReportable
{
public:
    virtual void showReport() = 0;
    virtual ~IReportable() {}
};

#endif
