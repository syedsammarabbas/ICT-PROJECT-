#ifndef MANAGER_H
#define MANAGER_H

#include "Employee.h"
#include "IReportable.h"
using namespace std;

class Manager : public Employee, public IReportable
{
private:
    int totalCashiers;

public:
    Manager();
    Manager(int id, string name, string phone,
            string username, string password);

    void addCashier();
    int getTotalCashiers();

    void showReport();

    void display();
    string getRole();

    void saveToFile(ofstream &file);
    void loadFromFile(ifstream &file);
};

#endif
