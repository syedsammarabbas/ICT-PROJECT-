#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>
using namespace std;
class Person
{
protected:
    string name;
    string phone;

public:
    Person();
    Person(string n, string p);

    string getName();
    string getPhone();

    void setName(string n);
    void setPhone(string p);

    virtual void display();
    virtual string getRole();
};

#endif
