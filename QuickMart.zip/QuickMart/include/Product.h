#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>
#include <string>
#include <fstream>
using namespace std;
class Product
{
protected:
    int productId;
    string name;
    double price;
    int stock;

public:
    Product();
    Product(int id, string name, double price, int stock);

    int getId();
    string getName();
    double getPrice();
    int getStock();

    void setName(string n);
    void setPrice(double p);
    void setStock(int s);

    void reduceStock(int qty);
    bool isAvailable(int qty);

    virtual ~Product() {}

    virtual double getFinalPrice();
    virtual string getType();
    virtual void display();

    virtual void saveToFile(ofstream &file);
    virtual void loadFromFile(ifstream &file);
};

#endif
