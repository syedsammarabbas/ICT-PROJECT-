#include <string>
#ifndef STORE_H
#define STORE_H

#include "Manager.h"
#include "Cashier.h"
#include "Product.h"
#include "DiscountedProduct.h"
#include "BundleProduct.h"
#include "Bill.h"
using namespace std;
class Store
{
private:
    string storeName;

    Manager manager;

    Product *products[100];
    int productCount;
    int nextProductId;

    Cashier cashiers[10];
    int cashierCount;
    int nextCashierId;

    Bill bills[500];
    int billCount;
    int nextBillId;

    Product *findProduct(int id);

public:
    Store(string name);
    ~Store();

    bool managerLogin();
    int cashierLogin();

    void managerMenu();
    void cashierMenu(int index);

    void showProducts();
    void addProduct();
    void editProduct();
    void deleteProduct();

    void addCashier();
    void removeCashier();
    void showCashiers();

    void newBill(int cashierIndex);
    void showDailySummary();

    void saveAll();
    void loadAll();
    void loadDefaultData();
};

#endif
