#ifndef UTILS_H
#define UTILS_H

void printDoubleLine();   // "=========================================="
void printSingleLine();   // "------------------------------------------"
void printBillDoubleLine(); // "  =========================================="
void printBillSingleLine(); // "  ------------------------------------------"

#endif
