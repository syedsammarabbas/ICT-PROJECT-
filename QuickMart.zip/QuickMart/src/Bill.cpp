#include "Bill.h"
#include "utils.h"
#include <iomanip>
using namespace std;

Bill::Bill()
{
    billId = 0;
    cashierId = 0;
    cashierName = "";
    customerName = "";
    paymentMethod = "Cash";
    itemCount = 0;
    subtotal = 0;
    tax = 0;
    grandTotal = 0;
}

Bill::Bill(int bid, int cid, string cname, string custName)
{
    billId = bid;
    cashierId = cid;
    cashierName = cname;
    customerName = custName;
    paymentMethod = "Cash";
    itemCount = 0;
    subtotal = 0;
    tax = 0;
    grandTotal = 0;
}

void Bill::addItem(int productId, string name, string type, int qty, double unitPrice)
{
    items[itemCount].productId = productId;
    items[itemCount].productName = name;
    items[itemCount].productType = type;
    items[itemCount].qty = qty;
    items[itemCount].unitPrice = unitPrice;
    items[itemCount].lineTotal = qty * unitPrice;

    itemCount = itemCount + 1;
}

void Bill::setPaymentMethod(string method)
{
    paymentMethod = method;
}

void Bill::calculateTotals()
{
    subtotal = 0;

    for (int i = 0; i < itemCount; i++)
    {
        subtotal = subtotal + items[i].lineTotal;
    }

    tax = subtotal * 0.17;
    grandTotal = subtotal + tax;
}

int Bill::getBillId() { 
    return billId; 
}
int Bill::getCashierId() { 
    return cashierId; 
}
double Bill::getGrandTotal() { 
    return grandTotal; 
}
int Bill::getItemCount() { 
    return itemCount;
 }

void Bill::printReceipt(string storeName)
{
    calculateTotals();

    cout << endl;
    printBillDoubleLine();
    cout << "            " << storeName << endl;
    printBillDoubleLine();
    cout << "  Bill No  : " << billId << endl;
    cout << "  Cashier  : " << cashierName << endl;
    cout << "  Customer : " << customerName << endl;
    cout << "  Payment  : " << paymentMethod << endl;
    printBillSingleLine();

    cout << left << setw(20) << "  Item"
         << right << setw(5) << "Qty"
         << setw(10) << "Price"
         << setw(10) << "Total" << endl;

    printBillSingleLine();

    for (int i = 0; i < itemCount; i++)
    {
        cout << left << setw(20) << ("  " + items[i].productName)
             << right << setw(5) << items[i].qty
             << setw(10) << fixed << setprecision(2) << items[i].unitPrice
             << setw(10) << items[i].lineTotal << endl;
    }

    printBillSingleLine();
    cout << right << setw(35) << "Subtotal : Rs." << setw(10) << subtotal << endl;
    cout << right << setw(35) << "Tax 17%  : Rs." << setw(10) << tax << endl;
    printBillDoubleLine();
    cout << right << setw(35) << "TOTAL    : Rs." << setw(10) << grandTotal << endl;
    printBillDoubleLine();
    cout << "         Thank you for shopping!" << endl;
    printBillDoubleLine();
    cout << endl;
}

void Bill::saveToFile(ofstream &file)
{
    file << billId << "\n";
    file << cashierId << "\n";
    file << cashierName << "\n";
    file << customerName << "\n";
    file << paymentMethod << "\n";
    file << itemCount << "\n";

    for (int i = 0; i < itemCount; i++)
    {
        file << items[i].productId << "\n";
        file << items[i].productName << "\n";
        file << items[i].productType << "\n";
        file << items[i].qty << "\n";
        file << items[i].unitPrice << "\n";
        file << items[i].lineTotal << "\n";
    }
}

void Bill::loadFromFile(ifstream &file)
{
    file >> billId >> cashierId;
    file.ignore();
    getline(file, cashierName);
    getline(file, customerName);
    getline(file, paymentMethod);
    file >> itemCount;
    file.ignore();

    for (int i = 0; i < itemCount; i++)
    {
        file >> items[i].productId;
        file.ignore();
        getline(file, items[i].productName);
        getline(file, items[i].productType);
        file >> items[i].qty >> items[i].unitPrice >> items[i].lineTotal;
        file.ignore();
    }

    calculateTotals();
}
