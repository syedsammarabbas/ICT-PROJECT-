#include "BundleProduct.h"
#include <iomanip>
using namespace std;

BundleProduct::BundleProduct()
{
    itemsInBundle = 1;
}

BundleProduct::BundleProduct(int id, string n, double p, int s, double d, int items)
{
    productId     = id;
    name          = n;
    price         = p;
    stock         = s;
    discount      = d;
    itemsInBundle = items;
}

int BundleProduct::getItemsInBundle()
{
    return itemsInBundle;
}

void BundleProduct::setItemsInBundle(int n)
{
    itemsInBundle = n;
}

double BundleProduct::getFinalPrice()
{
    double saving     = price * discount / 100;
    double unitPrice  = price - saving;
    double total      = unitPrice * itemsInBundle;
    return total;
}

string BundleProduct::getType()
{
    return "Bundle";
}

void BundleProduct::display()
{
    cout << left  << setw(4)  << productId
         << setw(22) << name
         << "Rs." << setw(10) << fixed << setprecision(2) << getFinalPrice()
         << "Stock: " << stock
         << "  [Bundle x" << itemsInBundle << ", " << discount << "% OFF]" << endl;
}

void BundleProduct::saveToFile(ofstream &file)
{
    DiscountedProduct::saveToFile(file);
    file << itemsInBundle << "\n";
}

void BundleProduct::loadFromFile(ifstream &file)
{
    DiscountedProduct::loadFromFile(file);
    file >> itemsInBundle;
    file.ignore();
}
