#include "Cashier.h"
using namespace std;

Cashier::Cashier()
{
    totalBills  = 0;
    totalAmount = 0;
}

Cashier::Cashier(int i, string n, string p, string user, string pass)
{
    id          = i;
    name        = n;
    phone       = p;
    username    = user;
    password    = pass;
    totalBills  = 0;
    totalAmount = 0;
}

void Cashier::addSale(double amount)
{
    totalBills  = totalBills + 1;
    totalAmount = totalAmount + amount;
}

int Cashier::getTotalBills()
{
    return totalBills;
}

double Cashier::getTotalAmount()
{
    return totalAmount;
}

void Cashier::display()
{
    cout << "[ CASHIER ]"                       << endl;
    cout << "ID           : " << id             << endl;
    cout << "Name         : " << name           << endl;
    cout << "Username     : " << username       << endl;
    cout << "Total Bills  : " << totalBills     << endl;
    cout << "Total Amount : " << totalAmount    << endl;
}

string Cashier::getRole()
{
    return "Cashier";
}

void Cashier::saveToFile(ofstream &file)
{
    Employee::saveToFile(file);
    file << totalBills  << "\n";
    file << totalAmount << "\n";
}

void Cashier::loadFromFile(ifstream &file)
{
    Employee::loadFromFile(file);
    file >> totalBills;
    file >> totalAmount;
    file.ignore();
}
