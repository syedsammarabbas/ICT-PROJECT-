#include "DiscountedProduct.h"
#include <iomanip>
using namespace std;

DiscountedProduct::DiscountedProduct()
{
    discount = 0;
}

DiscountedProduct::DiscountedProduct(int id, string n, double p, int s, double d)
{
    productId = id;
    name      = n;
    price     = p;
    stock     = s;
    discount  = d;
}

double DiscountedProduct::getDiscount()
{
    return discount;
}

void DiscountedProduct::setDiscount(double d)
{
    discount = d;
}

double DiscountedProduct::getFinalPrice()
{
    double saving      = price * discount / 100;
    double finalPrice  = price - saving;
    return finalPrice;
}

string DiscountedProduct::getType()
{
    return "Discounted";
}

void DiscountedProduct::display()
{
    cout << left  << setw(4)  << productId
         << setw(22) << name
         << "Rs." << setw(10) << fixed << setprecision(2) << getFinalPrice()
         << "Stock: " << stock
         << "  [" << discount << "% OFF]" << endl;
}

void DiscountedProduct::saveToFile(ofstream &file)
{
    Product::saveToFile(file);
    file << discount << "\n";
}

void DiscountedProduct::loadFromFile(ifstream &file)
{
    Product::loadFromFile(file);
    file >> discount;
    file.ignore();
}
