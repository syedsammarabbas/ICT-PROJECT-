#include "Employee.h"
using namespace std;

Employee::Employee()
{
    id       = 0;
    username = "";
    password = "";
}

Employee::Employee(int i, string n, string p, string user, string pass)
{
    id       = i;
    name     = n;
    phone    = p;
    username = user;
    password = pass;
}

int Employee::getId()
{
    return id;
}

string Employee::getUsername()
{
    return username;
}

bool Employee::checkLogin(string user, string pass)
{
    if (username == user && password == pass)
    {
        return true;
    }
    return false;
}

void Employee::display()
{
    cout << "ID       : " << id       << endl;
    cout << "Name     : " << name     << endl;
    cout << "Phone    : " << phone    << endl;
    cout << "Username : " << username << endl;
}

string Employee::getRole()
{
    return "Employee";
}

void Employee::saveToFile(ofstream &file)
{
    file << id       << "\n";
    file << name     << "\n";
    file << phone    << "\n";
    file << username << "\n";
    file << password << "\n";
}

void Employee::loadFromFile(ifstream &file)
{
    file >> id;
    file.ignore();
    getline(file, name);
    getline(file, phone);
    getline(file, username);
    getline(file, password);
}
