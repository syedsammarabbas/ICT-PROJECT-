#include "Manager.h"
#include "utils.h"
using namespace std;

Manager::Manager()
{
    totalCashiers = 0;
}

Manager::Manager(int i, string n, string p, string user, string pass)
{
    id            = i;
    name          = n;
    phone         = p;
    username      = user;
    password      = pass;
    totalCashiers = 0;
}

void Manager::addCashier()
{
    totalCashiers = totalCashiers + 1;
}

int Manager::getTotalCashiers()
{
    return totalCashiers;
}

void Manager::showReport()
{
    printDoubleLine();
    cout << "       MANAGER REPORT         " << endl;
    printDoubleLine();
    cout << "Name          : " << name          << endl;
    cout << "Total Cashiers: " << totalCashiers  << endl;
    printDoubleLine();
}

void Manager::display()
{
    cout << "[ MANAGER ]"                      << endl;
    cout << "ID       : " << id                << endl;
    cout << "Name     : " << name              << endl;
    cout << "Username : " << username          << endl;
    cout << "Cashiers : " << totalCashiers     << endl;
}

string Manager::getRole()
{
    return "Manager";
}

void Manager::saveToFile(ofstream &file)
{
    Employee::saveToFile(file);
    file << totalCashiers << "\n";
}

void Manager::loadFromFile(ifstream &file)
{
    Employee::loadFromFile(file);
    file >> totalCashiers;
    file.ignore();
}
