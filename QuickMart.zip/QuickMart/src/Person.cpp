#include "Person.h"
using namespace std;

Person::Person()
{
    name  = "";
    phone = "";
}

Person::Person(string n, string p)
{
    name  = n;
    phone = p;
}

string Person::getName()
{
    return name;
}

string Person::getPhone()
{
    return phone;
}

void Person::setName(string n)
{
    name = n;
}

void Person::setPhone(string p)
{
    phone = p;
}

void Person::display()
{
    cout << "Name  : " << name  << endl;
    cout << "Phone : " << phone << endl;
}

string Person::getRole()
{
    return "Person";
}
