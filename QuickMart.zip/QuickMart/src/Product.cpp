#include "Product.h"
#include <iomanip>
using namespace std;

Product::Product()
{
    productId = 0;
    name      = "";
    price     = 0;
    stock     = 0;
}

Product::Product(int id, string n, double p, int s)
{
    productId = id;
    name      = n;
    price     = p;
    stock     = s;
}

int    Product::getId()    { return productId; }
string Product::getName()  { return name; }
double Product::getPrice() { return price; }
int    Product::getStock() { return stock; }

void Product::setName(string n)  { name  = n; }
void Product::setPrice(double p) { price = p; }
void Product::setStock(int s)    { stock = s; }

void Product::reduceStock(int qty)
{
    stock = stock - qty;
}

bool Product::isAvailable(int qty)
{
    if (stock >= qty)
    {
        return true;
    }
    return false;
}

double Product::getFinalPrice()
{
    return price;
}

string Product::getType()
{
    return "General";
}

void Product::display()
{
    cout << left  << setw(4)  << productId
         << setw(22) << name
         << "Rs." << setw(10) << fixed << setprecision(2) << getFinalPrice()
         << "Stock: " << stock
         << "  [" << getType() << "]" << endl;
}

void Product::saveToFile(ofstream &file)
{
    file << productId << "\n";
    file << name      << "\n";
    file << price     << "\n";
    file << stock     << "\n";
}

void Product::loadFromFile(ifstream &file)
{
    file >> productId;
    file.ignore();
    getline(file, name);
    file >> price;
    file >> stock;
    file.ignore();
}
