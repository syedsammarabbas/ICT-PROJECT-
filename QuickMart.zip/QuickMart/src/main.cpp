#include <iostream>
#include <string>
#include <fstream>
#include "Store.h"
#include "utils.h"
using namespace std;

int main()
{
   
    ofstream test("data/.keep");
    if (!test)
    {
        cout << "Please create a 'data' folder next to the program." << endl;
        return 1;
    }
    test.close();

    Store store("QuickMart");
    store.loadAll();

    ifstream check("data/products.txt");
    if (!check)
    {
        store.loadDefaultData();
    }
    check.close();

    int choice = 0;

    while (choice != 3)
    {
        cout << endl;
        printDoubleLine();
        cout << "       QUICKMART POS SYSTEM               " << endl;
        printDoubleLine();
        cout << "1. Manager Login" << endl;
        cout << "2. Cashier Login" << endl;
        cout << "3. Exit"          << endl;
        cout << "Choice: ";
        cin  >> choice;
        cin.ignore();

        if (choice == 1)
        {
            bool ok = store.managerLogin();

            if (ok)
            {
                cout << "Login successful." << endl;
                store.managerMenu();
            }
            else
            {
                cout << "Wrong username or password." << endl;
            }
        }
        else if (choice == 2)
        {
            int index = store.cashierLogin();

            if (index >= 0)
            {
                cout << "Login successful." << endl;
                store.cashierMenu(index);
            }
            else
            {
                cout << "Wrong username or password." << endl;
            }
        }
        else if (choice == 3)
        {
            store.saveAll();
            cout << "Goodbye!" << endl;
        }
        else
        {
            cout << "Invalid choice." << endl;
        }
    }

    return 0;
}
