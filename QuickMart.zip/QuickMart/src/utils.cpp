#include "utils.h"
#include <iostream>
using namespace std;

void printDoubleLine()
{
    cout << "==========================================" << endl;
}

void printSingleLine()
{
    cout << "------------------------------------------" << endl;
}

void printBillDoubleLine()
{
    cout << "  ==========================================" << endl;
}

void printBillSingleLine()
{
    cout << "  ------------------------------------------" << endl;
}
