#include "Store.h"
#include <iomanip>
using namespace std;

// ================================================
// CONSTRUCTOR — Initialize store data
// ================================================
Store::Store(string name)
{
    storeName     = name;
    productCount  = 0;
    nextProductId = 1;
    cashierCount  = 0;
    nextCashierId = 10;
    billCount     = 0;
    nextBillId    = 1;

 
    for (int i = 0; i < 100; i++)
        products[i] = nullptr;


    manager = Manager(1, "Admin", "0300-0000000", "admin", "admin123");
}

// ================================================
// DESTRUCTOR — Free product memory
// ================================================
Store::~Store()
{
    for (int i = 0; i < productCount; i++)
        delete products[i];
}

// ================================================
// FIND PRODUCT — Search by ID
// ================================================
Product* Store::findProduct(int id)
{
    for (int i = 0; i < productCount; i++)
    {
        if (products[i]->getId() == id)
            return products[i];
    }
    return nullptr;  
}

// ================================================
// MANAGER LOGIN
// ================================================
bool Store::managerLogin()
{
    string user, pass;
    cout << "Username: ";
    cin  >> user;
    cout << "Password: ";
    cin  >> pass;
    return manager.checkLogin(user, pass);
}

// ================================================
// CASHIER LOGIN — Returns index in array
// ================================================
int Store::cashierLogin()
{
    string user, pass;
    cout << "Username: ";
    cin  >> user;
    cout << "Password: ";
    cin  >> pass;

    for (int i = 0; i < cashierCount; i++)
    {
        if (cashiers[i].checkLogin(user, pass))
            return i;
    }
    return -1;  
}

// ================================================
// SHOW ALL PRODUCTS
// ================================================
void Store::showProducts()
{
    if (productCount == 0)
    {
        cout << "No products found." << endl;
        return;
    }

    cout << endl;
    cout << left << setw(4)  << "ID"
                 << setw(22) << "Name"
                 << setw(14) << "Price"
                 << "Stock" << endl;
    cout << "--------------------------------------------" << endl;

    for (int i = 0; i < productCount; i++)
        products[i]->display();

    cout << "--------------------------------------------" << endl;
}

// ================================================
// ADD PRODUCT
// ================================================
void Store::addProduct()
{
    cout << endl;
    cout << "Select product type:" << endl;
    cout << "1. General"          << endl;
    cout << "2. Discounted"       << endl;
    cout << "3. Bundle"           << endl;
    cout << "Choice: ";

    int type;
    cin >> type;
    cin.ignore();

    string name;
    double price;
    int    stock;

    cout << "Name  : ";
    getline(cin, name);

    cout << "Price : ";
    cin  >> price;

    cout << "Stock : ";
    cin  >> stock;

    if (price <= 0)
    {
        cout << "Price must be greater than 0." << endl;
        return;
    }
    if (stock < 0)
    {
        cout << "Stock cannot be negative." << endl;
        return;
    }

    if (type == 1)
    {
        products[productCount] = new Product(nextProductId, name, price, stock);
        productCount++;
        nextProductId++;
        cout << "General product added." << endl;
    }

    else if (type == 2)
    {
        double disc;
        cout << "Discount % : ";
        cin  >> disc;

        if (disc < 0 || disc > 100)
        {
            cout << "Invalid discount." << endl;
            return;
        }

        products[productCount] = new DiscountedProduct(nextProductId, name, price, stock, disc);
        productCount++;
        nextProductId++;
        cout << "Discounted product added." << endl;
    }

    // Bundle product
    else if (type == 3)
    {
        double disc;
        int    items;

        cout << "Discount % : ";
        cin  >> disc;

        cout << "Items in bundle: ";
        cin  >> items;

        if (disc < 0 || disc > 100)
        {
            cout << "Invalid discount." << endl;
            return;
        }
        if (items < 2)
        {
            cout << "Bundle must have at least 2 items." << endl;
            return;
        }

        products[productCount] = new BundleProduct(nextProductId, name, price, stock, disc, items);
        productCount++;
        nextProductId++;
        cout << "Bundle product added." << endl;
    }

    else
    {
        cout << "Invalid choice." << endl;
    }

    cin.ignore();
}

// ================================================
// EDIT PRODUCT
// ================================================
void Store::editProduct()
{
    showProducts();

    cout << "Enter Product ID to edit: ";
    int id;
    cin >> id;

    Product* p = findProduct(id);

    if (p == nullptr)
    {
        cout << "Product not found." << endl;
        return;
    }

    cout << "1. Edit Name"  << endl;
    cout << "2. Edit Price" << endl;
    cout << "3. Edit Stock" << endl;
    cout << "Choice: ";

    int choice;
    cin >> choice;
    cin.ignore();

    if (choice == 1)
    {
        string newName;
        cout << "New Name: ";
        getline(cin, newName);
        p->setName(newName);
        cout << "Name updated." << endl;
    }
    else if (choice == 2)
    {
        double newPrice;
        cout << "New Price: ";
        cin  >> newPrice;
        cin.ignore();

        if (newPrice <= 0)
            cout << "Invalid price." << endl;
        else
        {
            p->setPrice(newPrice);
            cout << "Price updated." << endl;
        }
    }
    else if (choice == 3)
    {
        int newStock;
        cout << "New Stock: ";
        cin  >> newStock;
        cin.ignore();

        if (newStock < 0)
            cout << "Invalid stock." << endl;
        else
        {
            p->setStock(newStock);
            cout << "Stock updated." << endl;
        }
    }
    else
    {
        cout << "Invalid choice." << endl;
    }
}

// ================================================
// DELETE PRODUCT
// ================================================
void Store::deleteProduct()
{
    showProducts();

    cout << "Enter Product ID to delete: ";
    int id;
    cin >> id;
    cin.ignore();

    int foundAt = -1;

    for (int i = 0; i < productCount; i++)
    {
        if (products[i]->getId() == id)
            foundAt = i;
    }

    if (foundAt == -1)
    {
        cout << "Product not found." << endl;
        return;
    }

    delete products[foundAt];

    for (int i = foundAt; i < productCount - 1; i++)
        products[i] = products[i + 1];

    productCount--;
    products[productCount] = nullptr;

    cout << "Product deleted." << endl;
}

// ================================================
// ADD CASHIER
// ================================================
void Store::addCashier()
{
    if (cashierCount >= 10)
    {
        cout << "Cashier limit reached." << endl;
        return;
    }

    string name, phone, user, pass;

    cout << "Name     : ";
    cin.ignore();
    getline(cin, name);

    cout << "Phone    : ";
    getline(cin, phone);

    cout << "Username : ";
    cin >> user;

    cout << "Password : ";
    cin >> pass;
    cin.ignore();

    cashiers[cashierCount] = Cashier(nextCashierId, name, phone, user, pass);
    cashierCount++;
    nextCashierId++;
    manager.addCashier();

    cout << "Cashier added. ID: " << (nextCashierId - 1) << endl;
}

// ================================================
// REMOVE CASHIER
// ================================================
void Store::removeCashier()
{
    if (cashierCount == 0)
    {
        cout << "No cashiers to remove." << endl;
        return;
    }

    showCashiers();

    cout << "Enter Cashier ID to remove: ";
    int id;
    cin >> id;
    cin.ignore();

    int foundAt = -1;

    for (int i = 0; i < cashierCount; i++)
    {
        if (cashiers[i].getId() == id)
            foundAt = i;
    }

    if (foundAt == -1)
    {
        cout << "Cashier not found." << endl;
        return;
    }

    for (int i = foundAt; i < cashierCount - 1; i++)
        cashiers[i] = cashiers[i + 1];

    cashierCount--;
    cout << "Cashier removed." << endl;
}

// ================================================
// SHOW ALL CASHIERS
// ================================================
void Store::showCashiers()
{
    if (cashierCount == 0)
    {
        cout << "No cashiers registered." << endl;
        return;
    }

    for (int i = 0; i < cashierCount; i++)
    {
        cout << endl;
        cashiers[i].display();
    }
}

// ================================================
// CREATE NEW BILL
// ================================================
void Store::newBill(int cashierIndex)
{
    if (billCount >= 500)
    {
        cout << "Bill storage is full." << endl;
        return;
    }

    string customerName;
    cout << "Customer Name: ";
    cin.ignore();
    getline(cin, customerName);

    Bill bill(nextBillId,
              cashiers[cashierIndex].getId(),
              cashiers[cashierIndex].getName(),
              customerName);

    showProducts();

    cout << endl;
    cout << "Add items. Enter 0 to finish." << endl;

    while (true)
    {
        cout << "Product ID: ";
        int pid;
        cin >> pid;

        if (pid == 0)
        {
            cin.ignore();
            break;
        }

        Product* p = findProduct(pid);

        if (p == nullptr)
        {
            cout << "Product not found. Try again." << endl;
            continue;
        }

        cout << "Quantity: ";
        int qty;
        cin >> qty;

        if (qty <= 0)
        {
            cout << "Quantity must be at least 1." << endl;
            continue;
        }

        if (p->isAvailable(qty) == false)
        {
            cout << "Not enough stock. Available: " << p->getStock() << endl;
            continue;
        }

        bill.addItem(p->getId(), p->getName(), p->getType(), qty, p->getFinalPrice());
        p->reduceStock(qty);

        cout << "Added: " << p->getName() << " x" << qty << endl;
    }

    if (bill.getItemCount() == 0)
    {
        cout << "No items added. Bill cancelled." << endl;
        return;
    }

    cout << endl;
    cout << "Payment Method:" << endl;
    cout << "1. Cash"        << endl;
    cout << "2. Card"        << endl;
    cout << "3. Easypaisa"   << endl;
    cout << "Choice: ";

    int pm;
    cin >> pm;
    cin.ignore();

    if      (pm == 1) bill.setPaymentMethod("Cash");
    else if (pm == 2) bill.setPaymentMethod("Card");
    else if (pm == 3) bill.setPaymentMethod("Easypaisa");
    else              bill.setPaymentMethod("Cash");

    bill.printReceipt(storeName);
    cashiers[cashierIndex].addSale(bill.getGrandTotal());


    bills[billCount] = bill;
    billCount++;
    nextBillId++;
}

// ================================================
// DAILY SALES SUMMARY
// ================================================
void Store::showDailySummary()
{
    cout << endl;
    cout << "==========================================" << endl;
    cout << "          DAILY SALES SUMMARY             " << endl;
    cout << "==========================================" << endl;

    if (billCount == 0)
    {
        cout << "No sales today." << endl;
        return;
    }

    double totalRevenue = 0;

    for (int i = 0; i < billCount; i++)
    {
        cout << "Bill #"       << bills[i].getBillId()
             << "  Cashier: "  << bills[i].getCashierId()
             << "  Total: Rs." << fixed << setprecision(2)
             << bills[i].getGrandTotal() << endl;

        totalRevenue = totalRevenue + bills[i].getGrandTotal();
    }

    cout << "------------------------------------------" << endl;
    cout << "Total Bills    : " << billCount             << endl;
    cout << "Total Revenue  : Rs." << fixed << setprecision(2)
         << totalRevenue << endl;
    cout << "==========================================" << endl;
}

// ================================================
// MANAGER MENU
// ================================================
void Store::managerMenu()
{
    int choice = 0;

    while (choice != 8)
    {
        cout << endl;
        cout << "==========================================" << endl;
        cout << "   " << storeName << " — MANAGER PANEL"   << endl;
        cout << "==========================================" << endl;
        cout << "1. View Products"    << endl;
        cout << "2. Add Product"      << endl;
        cout << "3. Edit Product"     << endl;
        cout << "4. Delete Product"   << endl;
        cout << "5. Manage Cashiers"  << endl;
        cout << "6. Sales Report"     << endl;
        cout << "7. Manager Info"     << endl;
        cout << "8. Save & Logout"    << endl;
        cout << "Choice: ";
        cin  >> choice;
        cin.ignore();

        if      (choice == 1) showProducts();
        else if (choice == 2) addProduct();
        else if (choice == 3) editProduct();
        else if (choice == 4) deleteProduct();
        else if (choice == 5)
        {
            int c;
            cout << "1. Show Cashiers"  << endl;
            cout << "2. Add Cashier"    << endl;
            cout << "3. Remove Cashier" << endl;
            cout << "Choice: ";
            cin  >> c;
            cin.ignore();

            if      (c == 1) showCashiers();
            else if (c == 2) addCashier();
            else if (c == 3) removeCashier();
        }
        else if (choice == 6) showDailySummary();
        else if (choice == 7)
        {
            manager.display();
            manager.showReport();
        }
        else if (choice == 8)
        {
            saveAll();
            cout << "Data saved. Logged out." << endl;
        }
        else
        {
            cout << "Invalid choice." << endl;
        }
    }
}

// ================================================
// CASHIER MENU
// ================================================
void Store::cashierMenu(int index)
{
    int choice = 0;

    while (choice != 3)
    {
        cout << endl;
        cout << "==========================================" << endl;
        cout << "   " << storeName << " — CASHIER PANEL"   << endl;
        cout << "   Welcome, " << cashiers[index].getName() << endl;
        cout << "==========================================" << endl;
        cout << "1. New Bill"       << endl;
        cout << "2. View Products"  << endl;
        cout << "3. Logout"         << endl;
        cout << "Choice: ";
        cin  >> choice;
        cin.ignore();

        if (choice == 1)
        {
            newBill(index);
            saveAll();
        }
        else if (choice == 2) showProducts();
        else if (choice == 3)
        {
            saveAll();
            cout << "Logged out." << endl;
        }
        else
        {
            cout << "Invalid choice." << endl;
        }
    }
}

// ================================================
// SAVE ALL DATA TO FILES
// ================================================
void Store::saveAll()
{

    ofstream pFile("data/products.txt");
    if (pFile)
    {
        pFile << nextProductId << "\n";
        pFile << productCount  << "\n";

        for (int i = 0; i < productCount; i++)
        {
            pFile << products[i]->getType() << "\n";
            products[i]->saveToFile(pFile);
        }
        pFile.close();
    }

   
    ofstream cFile("data/cashiers.txt");
    if (cFile)
    {
        cFile << nextCashierId << "\n";
        cFile << cashierCount  << "\n";

        for (int i = 0; i < cashierCount; i++)
            cashiers[i].saveToFile(cFile);

        cFile.close();
    }


    ofstream bFile("data/bills.txt");
    if (bFile)
    {
        bFile << nextBillId << "\n";
        bFile << billCount  << "\n";

        for (int i = 0; i < billCount; i++)
            bills[i].saveToFile(bFile);

        bFile.close();
    }
}

// ================================================
// LOAD ALL DATA FROM FILES
// ================================================
void Store::loadAll()
{

    ifstream pFile("data/products.txt");
    if (pFile)
    {
        int count;
        pFile >> nextProductId;
        pFile >> count;
        pFile.ignore();

        for (int i = 0; i < count; i++)
        {
            string type;
            getline(pFile, type);

            Product* p;

            if (type == "Discounted")
                p = new DiscountedProduct();
            else if (type == "Bundle")
                p = new BundleProduct();
            else
                p = new Product();

            p->loadFromFile(pFile);
            products[productCount] = p;
            productCount++;
        }
        pFile.close();
    }

    ifstream cFile("data/cashiers.txt");
    if (cFile)
    {
        cFile >> nextCashierId;
        cFile >> cashierCount;
        cFile.ignore();

        for (int i = 0; i < cashierCount; i++)
            cashiers[i].loadFromFile(cFile);

        cFile.close();
    }

    ifstream bFile("data/bills.txt");
    if (bFile)
    {
        bFile >> nextBillId;
        bFile >> billCount;
        bFile.ignore();

        for (int i = 0; i < billCount; i++)
            bills[i].loadFromFile(bFile);

        bFile.close();
    }
}

void Store::loadDefaultData()
{
    // General products
    products[productCount] = new Product(nextProductId, "Banana",           850, 50);
    productCount++; nextProductId++;

    products[productCount] = new Product(nextProductId, "Sunflower Oil 1L", 480, 30);
    productCount++; nextProductId++;

    products[productCount] = new Product(nextProductId, "Sugar 1kg",        200, 80);
    productCount++; nextProductId++;

    products[productCount] = new Product(nextProductId, "Shampoo 400ml",    320, 20);
    productCount++; nextProductId++;

   
    products[productCount] = new DiscountedProduct(nextProductId, "Biscuits Pack", 120, 60, 10);
    productCount++; nextProductId++;

    products[productCount] = new DiscountedProduct(nextProductId, "Juice 1L",       90, 45, 15);
    productCount++; nextProductId++;

  
    products[productCount] = new BundleProduct(nextProductId, "Tea Bundle",  200, 25, 20, 3);
    productCount++; nextProductId++;

    products[productCount] = new BundleProduct(nextProductId, "Soap Bundle", 180, 20, 25, 4);
    productCount++; nextProductId++;


    cashiers[cashierCount] = Cashier(nextCashierId, "Ali Hassan", "0311-1234567", "cashier1", "pass123");
    cashierCount++;
    nextCashierId++;
    manager.addCashier();

    cout << "Default data loaded."          << endl;
    cout << "Manager : admin    / admin123" << endl;
    cout << "Cashier : cashier1 / pass123"  << endl;
}