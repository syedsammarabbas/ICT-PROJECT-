#include "bank.h"

void BankAccount::setAccount(int acc)
{
    accountNumber = acc;
    balance = 0;
}

void BankAccount::deposit(double amount)
{
    balance = balance + amount;
}

void BankAccount::withdraw(double amount)
{
    balance = balance - amount;
}

double BankAccount::getBalance()
{
    return balance;
}