#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H

class BankAccount
{
private:
    int accountNumber;
    double balance;

public:
    void setAccount(int ac);
    void deposit(double amount);
    void withdraw(double amount);
    double getBalance();
};

#endif