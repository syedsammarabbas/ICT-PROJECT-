#include <iostream>
#include "bank.h"

using namespace std;

int main()
{
    BankAccount acc;

    acc.setAccount(101);

    acc.deposit(5000);
    acc.withdraw(2000);

    cout << "Current Balance: " << acc.getBalance() << endl;

    return 0;
}