#include <iostream>
#include "calculator.h"

using namespace std;

int main()
{
    Calculator calc;
    double a, b;

    cout << "Enter two numbers: ";
    cin >> a >> b;

    cout << "Addition: " << calc.add(a,b) << endl;
    cout << "Subtraction: " << calc.subtract(a,b) << endl;
    cout << "Multiplication: " << calc.multiply(a,b) << endl;
    cout << "Division: " << calc.divide(a,b) << endl;

    return 0;
}