#include "Circle.h"

void Circle::setRadius(double rad)
{
    radius = rad;
}

double Circle::getRadius()
{
    return radius;
}

double Circle::getArea()
{
    return 3.14159 * radius * radius;
}