#ifndef CIRCLE_H
#define CIRCLE_H

class Circle
{
private:
    double radius;

public:
    void setRadius(double rad);
    double getRadius();
    double getArea();
};

#endif