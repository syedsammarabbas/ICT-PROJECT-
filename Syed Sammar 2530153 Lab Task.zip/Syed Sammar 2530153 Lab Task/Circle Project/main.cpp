#include <iostream>
#include "Circle.h"

using namespace std;

int main()
{
    Circle c;
    double r;

    cout << "Enter radius: ";
    cin >> r;

    c.setRadius(r);

    cout << "Radius: " << c.getRadius() << endl;
    cout << "Area: " << c.getArea() << endl;

    return 0;
}