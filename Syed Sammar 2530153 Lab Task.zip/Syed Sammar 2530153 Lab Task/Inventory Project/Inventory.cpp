#include <iostream>
#include "Inventory.h"

using namespace std;

void InventoryItem::setItem(int id, int quant, double pr)
{
    itemID = id;
    quantity = quant;
    price = pr;
}

void InventoryItem::updateQuantity(int quant)
{
    quantity = quantity + quant;
}

void InventoryItem::displayItem()
{
    cout << "Item ID: " << itemID << endl;
    cout << "Quantity: " << quantity << endl;
    cout << "Price: " << price << endl;
}