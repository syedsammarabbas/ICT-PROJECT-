#ifndef INVENTORYITEM_H
#define INVENTORYITEM_H

class InventoryItem
{
private:
    int itemID;
    int quantity;
    double price;

public:
    void setItem(int id, int quant, double pr);
    void updateQuantity(int quant);
    void displayItem();
};

#endif