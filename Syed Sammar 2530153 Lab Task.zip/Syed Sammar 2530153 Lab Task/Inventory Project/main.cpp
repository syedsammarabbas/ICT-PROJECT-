#include <iostream>
#include "Inventory.h"

using namespace std;

int main()
{
    InventoryItem item;

    item.setItem(1, 10, 50);

    item.updateQuantity(5);

    item.displayItem();

    return 0;
}