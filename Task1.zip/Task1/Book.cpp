#include "Book.h"

void Book::input() {
    cout << "Enter Title: ";
    cin >> title;
    cout << "Enter Author: ";
    cin >> author;
}

void Book::display() {
    cout << "Title: " << title << ", Author: " << author << endl;
}