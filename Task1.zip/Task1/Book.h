#ifndef BOOK_H
#define BOOK_H
#include <iostream>
using namespace std;

class Book {
public:
    string title;
    string author;

    void input();
    void display();
};

#endif