#include "Library.h"

void Library::addBooks() {
    for(int i=0;i<3;i++){
        cout << "\nBook " << i+1 << endl;
        books[i].input();
    }
}

void Library::displayLibrary() {
    cout << "\nLibrary Books:\n";
    for(int i=0;i<3;i++){
        books[i].display();
    }
}