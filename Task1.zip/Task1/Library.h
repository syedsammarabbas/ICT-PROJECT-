#ifndef LIBRARY_H
#define LIBRARY_H
#include "Book.h"

class Library {
private:
    Book books[3];

public:
    void addBooks();
    void displayLibrary();
};

#endif