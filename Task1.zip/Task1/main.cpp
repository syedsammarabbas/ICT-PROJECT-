#include "Library.h"

int main() {
    Library lib;
    lib.addBooks();
    lib.displayLibrary();
    return 0;
}