#include "Battery.h"

void Battery::input() {
    cout << "Enter Capacity: ";
    cin >> capacity;
    cout << "Enter Type: ";
    cin >> type;
}

void Battery::display() {
    cout << "Battery: " << capacity << "mAh, Type: " << type << endl;
}