#ifndef BATTERY_H
#define BATTERY_H
#include <iostream>
using namespace std;

class Battery {
public:
    int capacity;
    string type;

    void input();
    void display();
};

#endif