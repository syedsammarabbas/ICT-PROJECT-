#include "MobilePhone.h"

void MobilePhone::input() {
    cout << "Enter Brand: ";
    cin >> brand;
    battery.input();
}

void MobilePhone::display() {
    cout << "Brand: " << brand << endl;
    battery.display();
}