#ifndef MOBILEPHONE_H
#define MOBILEPHONE_H
#include "Battery.h"

class MobilePhone {
private:
    string brand;
    Battery battery;  

public:
    void input();
    void display();
};

#endif