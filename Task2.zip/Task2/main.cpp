#include "MobilePhone.h"

int main() {
    MobilePhone m;
    m.input();
    m.display();
    return 0;
}