#include "Doctor.h"

void Doctor::input() {
    cout << "Enter Doctor Name: ";
    cin >> name;
    cout << "Enter Specialization: ";
    cin >> specialization;
}

void Doctor::display() {
    cout << "Doctor: " << name << ", Spec: " << specialization << endl;
}