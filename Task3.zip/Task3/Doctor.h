#ifndef DOCTOR_H
#define DOCTOR_H
#include <iostream>
using namespace std;

class Doctor {
public:
    string name;
    string specialization;

    void input();
    void display();
};

#endif