#include "Hospital.h"

void Hospital::input() {
    cout << "Enter Hospital Name: ";
    cin >> hospitalName;

    for(int i=0;i<2;i++){
        cout << "\nDoctor " << i+1 << endl;
        d[i].input();
    }
}

void Hospital::display() {
    cout << "\nHospital: " << hospitalName << endl;
    for(int i=0;i<2;i++){
        d[i].display();
    }
}