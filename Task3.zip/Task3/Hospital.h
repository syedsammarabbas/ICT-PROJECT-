#ifndef HOSPITAL_H
#define HOSPITAL_H
#include "Doctor.h"

class Hospital {
private:
    string hospitalName;
    Doctor d[2]; 

public:
    void input();
    void display();
};

#endif