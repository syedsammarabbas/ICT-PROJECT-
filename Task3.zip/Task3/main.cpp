#include "Hospital.h"

int main() {
    Hospital h;
    h.input();
    h.display();
    return 0;
}