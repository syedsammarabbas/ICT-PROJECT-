#include "Building.h"

void Building::input() {
    cout << "Enter Building Name: ";
    cin >> name;
}

void Building::display() {
    cout << "Building: " << name << endl;
}