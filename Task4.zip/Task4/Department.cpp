#include "Department.h"

void Department::input() {
    cout << "\nEnter Department Name: ";
    cin >> deptName;

    building.input();

    for(int i=0;i<2;i++){
        cout << "Teacher " << i+1 << endl;
        t[i].input();
    }
}

void Department::display() {
    cout << "\nDepartment: " << deptName << endl;
    building.display();

    for(int i=0;i<2;i++){
        t[i].display();
    }
}