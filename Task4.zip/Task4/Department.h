#ifndef DEPARTMENT_H
#define DEPARTMENT_H
#include "Building.h"
#include "Teacher.h"

class Department {
private:
    string deptName;
    Building building;    
    Teacher t[2];          

public:
    void input();
    void display();
};

#endif