#include "Teacher.h"

void Teacher::input() {
    cout << "Enter Teacher Name: \n";
    cin >> name;
}

void Teacher::display() {
    cout << "Teacher: " << name << endl;
}