#ifndef TEACHER_H
#define TEACHER_H
#include <iostream>
using namespace std;

class Teacher {
public:
    string name;

    void input();
    void display();
};

#endif