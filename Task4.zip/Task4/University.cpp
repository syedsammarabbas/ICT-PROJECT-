#include "University.h"

void University::input() {
    cout << "Enter University Name: ";
    cin >> uniName;

    for(int i=0;i<2;i++){
        cout << "\nDepartment " << i+1 << endl;
        d[i].input();
    }
}

void University::display() {
    cout << "\nUniversity: " << uniName << endl;

    for(int i=0;i<2;i++){
        d[i].display();
    }
}