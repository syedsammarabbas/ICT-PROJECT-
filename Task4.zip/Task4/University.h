#ifndef UNIVERSITY_H
#define UNIVERSITY_H
#include "Department.h"

class University {
private:
    string uniName;
    Department d[2]; 

public:
    void input();
    void display();
};

#endif