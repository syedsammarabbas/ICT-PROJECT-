#include "University.h"

int main() {
    University u;

    u.input();
    u.display();

    return 0;
}