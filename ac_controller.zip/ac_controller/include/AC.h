#ifndef AC_H
#define AC_H

#include <iostream>
#include <string>
using namespace std;

class AC {
private:
    int id;
    string roomName;
    int temperature;   // 16 to 30
    string mode;       // Cool, Heat, Fan, Auto
    bool isOn;

public:
    AC();
    AC(int id, string roomName, int temp, string mode, bool isOn);

    // Getters
    int getId() const;
    string getRoomName() const;
    int getTemperature() const;
    string getMode() const;
    bool getStatus() const;

    // Setters
    void setRoomName(string name);
    void setTemperature(int temp);
    void setMode(string m);
    void setStatus(bool status);

    void display() const;
};

#endif
