#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "AC.h"
#include <fstream>

const int MAX_AC = 50;

class Controller {
private:
    AC acList[MAX_AC];
    int count;
    string filename;

    int findById(int id) const;
    bool idExists(int id) const;

public:
    Controller(string file = "ac_data.txt");

    void addAC();
    void displayAll() const;
    void searchAC() const;
    void updateAC();
    void deleteAC();
    void togglePower();

    void saveToFile() const;
    void loadFromFile();
};

#endif
