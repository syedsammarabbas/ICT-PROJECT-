#ifndef MENU_H
#define MENU_H

#include "Controller.h"

class Menu {
public:
    void showMainMenu() const;
    void run();
};

#endif
