#include "../include/AC.h"

AC::AC()
{
    id = 0;
    roomName = "No Room";
    temperature = 24;
    mode = "Cool";
    isOn = false;
}

AC::AC(int id, string room, int temp, string m, bool status)
{
    this->id = id;
    roomName = room;
    temperature = temp;
    mode = m;
    isOn = status;
}

int AC::getId() const
{
    return id;
}

string AC::getRoomName() const
{
    return roomName;
}

int AC::getTemperature() const
{
    return temperature;
}

string AC::getMode() const
{
    return mode;
}

bool AC::getStatus() const
{
    return isOn;
}

void AC::setRoomName(string name)
{
    roomName = name;
}

void AC::setTemperature(int temp)
{
    temperature = temp;
}

void AC::setMode(string m)
{
    mode = m;
}

void AC::setStatus(bool status)
{
    isOn = status;
}

void AC::display() const
{
    cout << "\nAC ID: " << id << endl;
    cout << "Room: " << roomName << endl;
    cout << "Temperature: " << temperature << endl;
    cout << "Mode: " << mode << endl;

    if(isOn)
    {
        cout << "Power: ON\n";
    }
    else
    {
        cout << "Power: OFF\n";
    }
}