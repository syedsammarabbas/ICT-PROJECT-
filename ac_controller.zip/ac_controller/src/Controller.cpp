#include "../include/Controller.h"
#include <iostream>
#include <fstream>

using namespace std;

Controller::Controller(string file)
{
    filename = file;
    count = 0;

    loadFromFile();
}

int Controller::findById(int id) const
{
    for(int i=0; i<count; i++)
    {
        if(acList[i].getId() == id)
        {
            return i;
        }
    }

    return -1;
}

bool Controller::idExists(int id) const
{
    return findById(id) != -1;
}

void Controller::addAC()
{
    int id, temp;
    string room;

    cout << "Enter ID: ";
    cin >> id;

    if(idExists(id))
    {
        cout << "ID Already Exists\n";
        return;
    }

    cin.ignore();

    cout << "Enter Room: ";
    getline(cin, room);

    cout << "Enter Temp: ";
    cin >> temp;

    acList[count] = AC(id, room, temp, "Cool", true);

    count++;

    saveToFile();

    cout << "AC Added\n";
}

void Controller::displayAll() const
{
    for(int i=0; i<count; i++)
    {
        acList[i].display();
    }
}

void Controller::searchAC() const
{
    int id;

    cout << "Enter ID: ";
    cin >> id;

    int index = findById(id);

    if(index == -1)
    {
        cout << "Not Found\n";
    }
    else
    {
        acList[index].display();
    }
}

void Controller::updateAC()
{
    int id, temp;

    cout << "Enter ID: ";
    cin >> id;

    int index = findById(id);

    if(index == -1)
    {
        cout << "Not Found\n";
        return;
    }

    cout << "Enter New Temp: ";
    cin >> temp;

    acList[index].setTemperature(temp);

    saveToFile();

    cout << "Updated\n";
}

void Controller::deleteAC()
{
    int id;

    cout << "Enter ID: ";
    cin >> id;

    int index = findById(id);

    if(index == -1)
    {
        cout << "Not Found\n";
        return;
    }

    for(int i=index; i<count-1; i++)
    {
        acList[i] = acList[i+1];
    }

    count--;

    saveToFile();

    cout << "Deleted\n";
}

void Controller::togglePower()
{
    int id;

    cout << "Enter ID: ";
    cin >> id;

    int index = findById(id);

    if(index == -1)
    {
        cout << "Not Found\n";
        return;
    }

    bool status = acList[index].getStatus();

    acList[index].setStatus(!status);

    saveToFile();

    cout << "Power Changed\n";
}

void Controller::saveToFile() const
{
    ofstream out(filename);

    out << count << endl;

    for(int i=0; i<count; i++)
    {
        out << acList[i].getId() << endl;
        out << acList[i].getRoomName() << endl;
        out << acList[i].getTemperature() << endl;
        out << acList[i].getMode() << endl;
        out << acList[i].getStatus() << endl;
    }

    out.close();
}

void Controller::loadFromFile()
{
    ifstream in(filename);

    if(!in)
    {
        return;
    }

    in >> count;

    in.ignore();

    for(int i=0; i<count; i++)
    {
        int id, temp;
        string room, mode;
        bool status;

        in >> id;

        in.ignore();

        getline(in, room);

        in >> temp >> mode >> status;

        in.ignore();

        acList[i] = AC(id, room, temp, mode, status);
    }

    in.close();
}