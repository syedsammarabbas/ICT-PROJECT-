#include "../include/Menu.h"
#include <iostream>
using namespace std;

void Menu::showMainMenu() const {
    cout << "\n  ================================\n";
    cout << "       AC CONTROLLER SYSTEM     \n";
    cout << "  ================================\n";
    cout << "  1. Add New AC\n";
    cout << "  2. Display All ACs\n";
    cout << "  3. Search AC by ID\n";
    cout << "  4. Update AC Settings\n";
    cout << "  5. Toggle AC Power (ON/OFF)\n";
    cout << "  6. Delete AC\n";
    cout << "  0. Exit\n";
    cout << "  ================================\n";
    cout << "  Enter your choice: ";
}

void Menu::run() {
    Controller ctrl("ac_data.txt");
    int choice;

    cout << "\n  Welcome to AC Controller System!\n";

    do {
        showMainMenu();
        cin >> choice;

        switch (choice) {
            case 1: ctrl.addAC();       break;
            case 2: ctrl.displayAll();  break;
            case 3: ctrl.searchAC();    break;
            case 4: ctrl.updateAC();    break;
            case 5: ctrl.togglePower(); break;
            case 6: ctrl.deleteAC();    break;
            case 0: cout << "  Goodbye! Exiting...\n"; break;
            default: cout << "  [!] Invalid choice. Try again.\n";
        }

    } while (choice != 0);
}
